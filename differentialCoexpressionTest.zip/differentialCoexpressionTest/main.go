package main

import (
	"encoding/csv"
	"log"
	"os"
	"strconv"
)

func main() {
	// Load module assignments
	moduleMap, err := loadModules("data/rat/diffcoex_results_mouse.csv")
	if err != nil {
		log.Fatal("Error loading modules:", err)
	}

	// Load expression data
	data1, err := loadExpressionData("data/rat/rat_eker_mutants.csv")
	if err != nil {
		log.Fatal("Error loading AML data:", err)
	}

	data2, err := loadExpressionData("data/rat/rat_wild_types.csv")
	if err != nil {
		log.Fatal("Error loading ALL data:", err)
	}

	// Create output CSV file
	outputFile, err := os.Create("differential_coexpression_results.csv")
	if err != nil {
		log.Fatal("Cannot create output file:", err)
	}
	defer outputFile.Close()

	// Create CSV writer
	writer := csv.NewWriter(outputFile)
	defer writer.Flush()

	// Write header
	header := []string{"Module", "Size", "T-Statistic", "P-Value"}
	if err := writer.Write(header); err != nil {
		log.Fatal("Error writing header:", err)
	}

	// Analyze each module and write results
	for module := range getUniqueModules(moduleMap) {
		stats := analyzeModule(module, moduleMap, data1, data2)

		// Convert numbers to strings
		row := []string{
			stats.Name,
			strconv.Itoa(stats.Size),
			strconv.FormatFloat(stats.TStatistic, 'f', 6, 64),
			strconv.FormatFloat(stats.PValue, 'f', 6, 64),
		}

		if err := writer.Write(row); err != nil {
			log.Fatal("Error writing result:", err)
		}
	}
}
