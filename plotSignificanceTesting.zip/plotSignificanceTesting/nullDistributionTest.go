package main

import (
	"math/rand"
)

func sampleGenes(genes []string, size int, r *rand.Rand) []string {
	sampled := make([]string, size)
	indices := r.Perm(len(genes))
	for i := 0; i < size; i++ {
		sampled[i] = genes[indices[i]]
	}
	return sampled
}
