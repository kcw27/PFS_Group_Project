package main

import (
	"fmt"
	"image/color"
	"math"
	"math/rand"
	"runtime"
	"sync"
	"time"

	"gonum.org/v1/gonum/stat"
	"gonum.org/v1/plot"
	"gonum.org/v1/plot/plotter"
	"gonum.org/v1/plot/vg"
)

func generateNullCorrelations(moduleGenes, c1Genes, c2Genes []string,
	condition1Data, condition2Data map[string][]float64, numPermutations int) ([]float64, []float64) {

	moduleSize := len(moduleGenes)

	// Create channels for parallel processing
	c1Results := make(chan []float64, numPermutations)
	c2Results := make(chan []float64, numPermutations)

	// Create worker pool
	numWorkers := runtime.GOMAXPROCS(0)
	var wg sync.WaitGroup

	// Launch workers for condition 1
	for w := 0; w < numWorkers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			r := rand.New(rand.NewSource(time.Now().UnixNano()))

			permutationsPerWorker := numPermutations / numWorkers
			for i := 0; i < permutationsPerWorker; i++ {
				// Randomly sample genes for null module
				nullGenes := sampleGenes(c1Genes, moduleSize, r)
				nullCorrs := getModuleCorrelations(nullGenes, condition1Data)
				c1Results <- nullCorrs
			}
		}()
	}

	// Launch workers for condition 2
	for w := 0; w < numWorkers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			r := rand.New(rand.NewSource(time.Now().UnixNano()))

			permutationsPerWorker := numPermutations / numWorkers
			for i := 0; i < permutationsPerWorker; i++ {
				nullGenes := sampleGenes(c2Genes, moduleSize, r)
				nullCorrs := getModuleCorrelations(nullGenes, condition2Data)
				c2Results <- nullCorrs
			}
		}()
	}

	// Close results channels when all workers are done
	go func() {
		wg.Wait()
		close(c1Results)
		close(c2Results)
	}()

	// Collect results
	var c1NullCorrs, c2NullCorrs []float64
	for corrs := range c1Results {
		c1NullCorrs = append(c1NullCorrs, corrs...)
	}
	for corrs := range c2Results {
		c2NullCorrs = append(c2NullCorrs, corrs...)
	}

	return c1NullCorrs, c2NullCorrs
}

func plotConditionDistribution(moduleName, conditionName string, actualCorrs, nullCorrs []float64) {
	p := plot.New()

	// Calculate t-statistic and p-value
	tstat, pval := calculateTStatistic(actualCorrs, nullCorrs)

	// Set plot title and labels with t-statistic and p-value
	p.Title.Text = fmt.Sprintf("Module %s - %s\nt-statistic: %.2f, p-value: %.4f",
		moduleName, conditionName, tstat, pval)
	p.X.Label.Text = "Correlation"
	p.Y.Label.Text = "Density"

	// Create histograms
	nullHist, _ := plotter.NewHist(plotter.Values(nullCorrs), 50)
	actualHist, _ := plotter.NewHist(plotter.Values(actualCorrs), 50)

	// Style the histograms
	nullHist.FillColor = color.RGBA{R: 200, B: 200, A: 255}
	nullHist.LineStyle.Width = vg.Points(1)
	nullHist.Normalize(1)

	actualHist.FillColor = color.RGBA{R: 255, A: 255}
	actualHist.LineStyle.Width = vg.Points(1)
	actualHist.Normalize(1)

	// Add to plot
	p.Add(nullHist, actualHist)

	// Add legend
	p.Legend.Add("Null Distribution", nullHist)
	p.Legend.Add("Actual Correlations", actualHist)
	p.Legend.Top = true

	// Save the plot
	filename := fmt.Sprintf("output/%s_%s_distribution.png", moduleName, conditionName)
	if err := p.Save(6*vg.Inch, 4*vg.Inch, filename); err != nil {
		fmt.Printf("Error saving plot: %v\n", err)
	}
}

func calculateTStatistic(actual, null []float64) (float64, float64) {
	// Calculate means
	actualMean := stat.Mean(actual, nil)
	nullMean := stat.Mean(null, nil)

	// Calculate variances
	actualVar := stat.Variance(actual, nil)
	nullVar := stat.Variance(null, nil)

	// Calculate standard error
	actualN := float64(len(actual))
	nullN := float64(len(null))
	se := math.Sqrt(actualVar/actualN + nullVar/nullN)

	// Calculate t-statistic
	t := (actualMean - nullMean) / se

	// For large df (>30), t-distribution approximates normal distribution
	// Calculate two-tailed p-value using normal approximation
	p := 2 * (1 - normalCDF(math.Abs(t)))

	return t, p
}

// normalCDF returns the cumulative distribution function of the standard normal distribution
func normalCDF(x float64) float64 {
	return 0.5 * (1 + math.Erf(x/math.Sqrt(2)))
}
